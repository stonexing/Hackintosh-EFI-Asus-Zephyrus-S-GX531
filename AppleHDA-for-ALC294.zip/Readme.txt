---------README----------

1.Install AppleHDA.kext to S/L/E with your favorite method.
2.Rebuild cache and repair permission.
3.Store CodecCommander.kext(THIS IS A SPECIAL EDITION) to Clover/Kexts/Other.
4.Store the folder Jack_Fix and run install.command.
5.ENJOY!

1.将 AppleHDA 安装到 S/L/E
2.重建缓存并修复权限
3.将 CodecCommander.kext (这是个特殊版本！) 放到 Clover/Kext/Other
4.把 Jack_Fix 整个文件夹拖到桌面并运行里面的 install.command
5.享受吧！
